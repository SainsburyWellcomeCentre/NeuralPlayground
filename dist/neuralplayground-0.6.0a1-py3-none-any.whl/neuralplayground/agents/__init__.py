name = 'models'
from .agent_core import AgentCore, RandomAgent
from .stachenfeld_2018 import SR
from .weber_2018 import ExcInhPlasticity