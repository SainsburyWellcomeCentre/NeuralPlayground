class Experiment(object):
    """Main experiment class, created just for consistency purposes"""
    pass
