name = 'models'
from .agent_core import NeuralResponseModel
from .stachenfeld_2018 import SR
from .weber_2018 import ExcInhPlasticity