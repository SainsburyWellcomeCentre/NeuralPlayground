#!/usr/bin/python

from sehec.crossrun.default_run import default_run
import sys

if __name__ == "__main__":
    default_run(sys.argv[1])
