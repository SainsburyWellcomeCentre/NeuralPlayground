#!/usr/bin/python

from neuralplayground.comparison_board.default_run import default_run
import sys

if __name__ == "__main__":
    default_run(sys.argv[1])
